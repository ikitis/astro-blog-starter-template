export const footerData = [
  {
    title: 'About Us',
    href: '#about-us'
  },
  {
    title: 'Testimonials',
    href: '#testimonials'
  },
  {
    title: 'Contact Us',
    href: '#contact-us'
  },
  {
    title: 'Offers',
    href: '#offers'
  }
]
