<!-- Available h3 headings: Added, Fixed, Updated, Removed, Deprecated -->

# Changelog

All notable changes to this template will be documented in this file

## v1.0.0 (2026-02-02)

### Added

- Initial release
- Contains following sections
  - Header
  - Hero Section
  - Popular Dishes
  - About Us
  - Testimonials
  - New Items
  - Contact Us
  - Offers
  - Footer
- Responsive Design
- Dark/Light Mode Toggle
- Smooth Scrolling
- SEO Optimization
